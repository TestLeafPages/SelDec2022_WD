package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class WelComePage extends BaseClass {	
      
	public WelComePage(ChromeDriver driver) {
		this.driver=driver;
	}

	public WelComePage verifyHomePage() {
		boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
		if (displayed) {
			System.out.println("Login successful");
		}
		else {
			System.out.println("Login unsuccessfull");
		}
		return this;
	}

	public MyHomePage clickCrmsfalink() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage(driver);
	}
}
