package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class VerifyLogin extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		ExcelFileName="Login";
		testName="Salesforce testcase-Login";
		testDescription="Login with Salesforce application";
		testCategory="Smoke";
		testAuthor="Subraja";
//		testNode="FirstIteration";
		
	}
	
	@Test(dataProvider="fetchData")
	public void runLogin(String username,String password) throws InterruptedException, IOException {
		
		 new LoginPage()
		.enterUsername(username).
		enterPassword(password).
		clickLoginButton().
		verifyHomePage()
		;
		
	
	}

}
