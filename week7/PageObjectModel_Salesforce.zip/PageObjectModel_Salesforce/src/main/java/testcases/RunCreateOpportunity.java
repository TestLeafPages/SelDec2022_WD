package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateOpportunity extends BaseClass{
	@BeforeTest
	public void setValues() {
		ExcelFileName="CreateOpportunity";
		testName="Salesforce - Create Opportunity";
		testDescription="Create Opportunity for Salesforce application";
		testCategory="Sanity";
		testAuthor="Subraja";

	}
	
	
	@Test(dataProvider="fetchData")
	public void runCreateLead(String uName,String pWord,String cName,String lName) throws InterruptedException, IOException {
		new LoginPage()
		.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyHomePage()
		.clickToggleButton()
        .clickSalesButton()
        .clickOpportunities()
        .clickNew()
        .enterOppName(cName)
        .enterCloseDate(lName)
        .enterOptions()
        .clickCreateSave()
        .verifyOpportunity();
        
	}

}
