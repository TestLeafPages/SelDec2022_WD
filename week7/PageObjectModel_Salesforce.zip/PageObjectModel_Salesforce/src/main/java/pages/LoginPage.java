package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	
    @Given("Enter the username as (.*)$")
	public LoginPage enterUsername(String username) throws InterruptedException, IOException {
		
		try {
			getDriver().findElement(By.name("username")).sendKeys(username);
			reportStep(username+"  is entered successfully", "pass");
			
		} catch (Exception e) {
			reportStep(e+"  is not entered successfully", "fail");
		}
		return this;
	}
   
    @And("Enter the password as (.*)$")
	public LoginPage enterPassword(String password) throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(password);
			reportStep(password+"  is entered successfully", "pass");
			
		} catch (Exception e) {
			reportStep(e+"  is not entered successfully", "fail");
		}
		return this;
	}

    @When("Click on Login button")
	public WelComePage clickLoginButton() throws IOException {
		try {
			getDriver().findElement(By.id("Login")).click();
			reportStep("Login successfull", "pass");
		} catch (Exception e) {
			reportStep("Login not successfull", "fail");
		}
		return new WelComePage();
	}

}
