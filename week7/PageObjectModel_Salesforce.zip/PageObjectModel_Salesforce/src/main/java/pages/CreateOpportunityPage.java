package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import base.BaseClass;
import io.cucumber.java.en.And;

public class CreateOpportunityPage extends BaseClass {

	@And("Enter the Opportunity name as (.*)$")
	public CreateOpportunityPage enterOppName(String oppName) throws IOException {
		try {
			getDriver().findElement(By.xpath("//label[text()='Opportunity Name']/following::input")).sendKeys(oppName);
			reportStep(oppName+" is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(oppName+" is not entered successfully", "fail");
		}
		return this;
	}

	@And("Enter the closeDate as (.*)$")
	public CreateOpportunityPage enterCloseDate(String date) throws IOException {
		try {
			getDriver().findElement(By.xpath("//label[text()='Close Date']/following::input")).sendKeys(date,Keys.ENTER);
			reportStep(date+" is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(date+" is not entered successfully", "fail");
		}
		return this;
	}

	@And("click None options")
	public CreateOpportunityPage enterOptions() throws InterruptedException, IOException {
		try {
			getDriver().findElement(By.xpath("//label[text()='Stage']/following::button[1]")).click();
			getDriver().findElement(By.xpath("//span[@title='Needs Analysis']")).click();
			reportStep("Options clicked successfully", "pass");
			
		} catch (Exception e) {
			reportStep("Options is not clicked successfully", "fail");
		}
		return this;
	}

	@And("Click Save button")
	public ViewOpportunityPage clickCreateSave() throws IOException {
		try {
			getDriver().findElement(By.xpath("//button[text()='Save']")).click();
			reportStep("Save button clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Save button is not clicked successfully", "fail");
		}
		return new ViewOpportunityPage();
	}
}
