package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;

public class TogglePage extends BaseClass{
	
     @And("Click on Sales link")
     public SalesPage clickSalesButton() throws IOException {
    		try {
				getDriver().findElement(By.xpath("//p[text()='Sales']")).click();
				reportStep("Salesbutton is clicked successfully", "pass");
			} catch (Exception e) {
				reportStep("Salesbutton is not clicked successfully", "fail");
			}
    		return new SalesPage();
	}
}
